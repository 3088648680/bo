package test.coursedesign.service;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import test.coursedesign.mapper.UserMapper;
import test.coursedesign.pojo.User;
import test.coursedesign.service.impl.UserServiceimpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceimplTest {

    @InjectMocks
    private UserServiceimpl userService;

    @Mock
    private UserMapper userMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterUser_Success() {
        User user = new User();
        user.setUsername("JohnDoe");
        user.setPassword("password123");

        doNothing().when(userMapper).registerUser(user);

        // 调用 Service 方法
        boolean result = userService.registerUser(user);

        // 验证结果
        assertTrue(result);

        // 验证 Mapper 方法调用
        verify(userMapper, times(1)).registerUser(user);
    }

    @Test
    void testRegisterUser_Fail_NullUsername() {
        User user = new User();
        user.setUsername(null);
        user.setPassword("password123");

        // 调用 Service 方法
        boolean result = userService.registerUser(user);

        // 验证结果
        assertFalse(result);

        // 验证 Mapper 方法未调用
        verify(userMapper, never()).registerUser(user);
    }

    @Test
    void testRegisterUser_Fail_Exception() {
        User user = new User();
        user.setUsername("JohnDoe");
        user.setPassword("password123");

        doThrow(new RuntimeException("Database error")).when(userMapper).registerUser(user);

        // 调用 Service 方法
        boolean result = userService.registerUser(user);

        // 验证结果
        assertFalse(result);

        // 验证 Mapper 方法调用
        verify(userMapper, times(1)).registerUser(user);
    }

    @Test
    void testLogin() {
        User user = new User();
        user.setUsername("JohnDoe");
        user.setPassword("password123");

        User mockUser = new User();
        mockUser.setUsername("JohnDoe");
        mockUser.setPassword("password123");

        when(userMapper.login(user)).thenReturn(mockUser);

        // 调用 Service 方法
        User result = userService.login(user);

        // 验证结果
        assertNotNull(result);
        assertEquals("JohnDoe", result.getUsername());
        assertEquals("password123", result.getPassword());

        // 验证 Mapper 方法调用
        verify(userMapper, times(1)).login(user);
    }

    @Test
    void testUserUpdate_Success() {
        User user = new User();
        user.setUsername("JohnDoe");
        user.setPassword("newPassword123");

        doNothing().when(userMapper).userupdate(user);

        // 调用 Service 方法
        boolean result = userService.userupdate(user);

        // 验证结果
        assertTrue(result);

        // 验证 Mapper 方法调用
        verify(userMapper, times(1)).userupdate(user);
    }

    @Test
    void testUserUpdate_Fail() {
        User user = new User();
        user.setUsername("JohnDoe");
        user.setPassword("newPassword123");

        doThrow(new RuntimeException("Database error")).when(userMapper).userupdate(user);

        // 调用 Service 方法
        boolean result = userService.userupdate(user);

        // 验证结果
        assertFalse(result);

        // 验证 Mapper 方法调用
        verify(userMapper, times(1)).userupdate(user);
    }
}

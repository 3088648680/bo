package test.coursedesign.service;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import test.coursedesign.mapper.ACMMapper;
import test.coursedesign.pojo.ACM;
import test.coursedesign.service.impl.ACMServiceimpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ACMServiceimplTest {

    @InjectMocks
    private ACMServiceimpl acmService;

    @Mock
    private ACMMapper acmMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsert() {
        ACM acm = new ACM();
        acm.setName("New ACM");

        // 调用 Service 方法
        acmService.insert(acm);

        // 验证 Mapper 方法调用
        verify(acmMapper, times(1)).insert(acm);
    }

    @Test
    void testDelete() {
        List<Integer> ids = List.of(1, 2, 3);

        // 调用 Service 方法
        acmService.delete(ids);

        // 验证 Mapper 方法调用
        verify(acmMapper, times(1)).delete(ids);
    }

    @Test
    void testSelect() {
        ACM acm = new ACM();
        acm.setName("Test ACM");

        List<ACM> mockACMs = new ArrayList<>();
        ACM resultACM = new ACM();
        resultACM.setName("Test ACM");
        mockACMs.add(resultACM);

        when(acmMapper.select(acm)).thenReturn(mockACMs);

        // 调用 Service 方法
        List<ACM> result = acmService.select(acm);

        // 验证结果
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test ACM", result.get(0).getName());

        // 验证 Mapper 方法调用
        verify(acmMapper, times(1)).select(acm);
    }

    @Test
    void testUpdate() {
        ACM acm = new ACM();
        acm.setName("Updated ACM");

        // 调用 Service 方法
        acmService.update(acm);

        // 验证 Mapper 方法调用
        verify(acmMapper, times(1)).update(acm);
    }
}



package test.coursedesign.service;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import test.coursedesign.mapper.CWMMapper;
import test.coursedesign.pojo.CWM;
import test.coursedesign.service.impl.CWMServiceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CWMServiceimplTest {

    @InjectMocks
    private CWMServiceimpl cwmService;

    @Mock
    private CWMMapper cwmMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsert() {
        CWM cwm = new CWM();
        cwm.setTitle("New Task");
        cwm.setDescription("Task Description");
        cwm.setSubmitDate(new Date());

        // 调用 Service 方法
        cwmService.insert(cwm);

        // 验证 Mapper 方法调用
        verify(cwmMapper, times(1)).insert(cwm);
    }

    @Test
    void testDelete() {
        List<Integer> ids = List.of(1, 2, 3);

        // 调用 Service 方法
        cwmService.delete(ids);

        // 验证 Mapper 方法调用
        verify(cwmMapper, times(1)).delete(ids);
    }


    @Test
    void testSelect2() {
        CWM query = new CWM();
        query.setTitle("General Task");

        List<CWM> mockResults = new ArrayList<>();
        CWM result = new CWM();
        result.setTitle("General Task");
        mockResults.add(result);

        when(cwmMapper.select2(query)).thenReturn(mockResults);

        // 调用 Service 方法
        List<CWM> results = cwmService.select2(query);

        // 验证结果
        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("General Task", results.get(0).getTitle());

        // 验证 Mapper 方法调用
        verify(cwmMapper, times(1)).select2(query);
    }

    @Test
    void testUpdate() {
        CWM cwm = new CWM();
        cwm.setTitle("Updated Task");
        cwm.setDescription("Updated Description");

        // 调用 Service 方法
        cwmService.update(cwm);

        // 验证 Mapper 方法调用
        verify(cwmMapper, times(1)).update(cwm);
    }
}


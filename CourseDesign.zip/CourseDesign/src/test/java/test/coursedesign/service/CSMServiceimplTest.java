package test.coursedesign.service;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import test.coursedesign.mapper.CSMMapper;
import test.coursedesign.pojo.CSM;
import test.coursedesign.service.impl.CSMServiceimpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CSMServiceimplTest {

    @InjectMocks
    private CSMServiceimpl csmService;

    @Mock
    private CSMMapper csmMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsert() {
        CSM csm = new CSM();
        csm.setName("New CSM");

        // 调用 Service 方法
        csmService.insert(csm);

        // 验证 Mapper 方法调用
        verify(csmMapper, times(1)).insert(csm);
    }

    @Test
    void testDelete() {
        List<Integer> ids = List.of(1, 2, 3);

        // 调用 Service 方法
        csmService.delete(ids);

        // 验证 Mapper 方法调用
        verify(csmMapper, times(1)).delete(ids);
    }

    @Test
    void testSelect2() {
        CSM query = new CSM();
        query.setName("Test CSM");

        List<CSM> mockResults = new ArrayList<>();
        CSM result = new CSM();
        result.setName("Test CSM");
        mockResults.add(result);

        when(csmMapper.select2(query)).thenReturn(mockResults);

        // 调用 Service 方法
        List<CSM> results = csmService.select2(query);

        // 验证结果
        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("Test CSM", results.get(0).getName());

        // 验证 Mapper 方法调用
        verify(csmMapper, times(1)).select2(query);
    }

    @Test
    void testUpdate() {
        CSM csm = new CSM();
        csm.setName("Updated CSM");

        // 调用 Service 方法
        csmService.update(csm);

        // 验证 Mapper 方法调用
        verify(csmMapper, times(1)).update(csm);
    }
}

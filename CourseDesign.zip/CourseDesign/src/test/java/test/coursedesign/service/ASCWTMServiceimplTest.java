package test.coursedesign.service;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import test.coursedesign.mapper.ASCWTMMapper;
import test.coursedesign.pojo.ASCWTM;
import test.coursedesign.service.impl.ASCWTMServiceimpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ASCWTMServiceimplTest {

    @InjectMocks
    private ASCWTMServiceimpl ascwtmService;

    @Mock
    private ASCWTMMapper ascwtmMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsert() {
        ASCWTM ascwtm = new ASCWTM();
        ascwtm.setStudentId("S123");
        ascwtm.setTutorName("Dr. Smith");
        ascwtm.setSubjectName("Math");
        ascwtm.setHomeworkTitle("Algebra Homework");

        // 调用 Service 方法
        ascwtmService.insert(ascwtm);

        // 验证 Mapper 方法调用
        verify(ascwtmMapper, times(1)).insert(ascwtm);
    }

    @Test
    void testDelete() {
        List<Integer> ids = List.of(1, 2, 3);

        // 调用 Service 方法
        ascwtmService.delete(ids);

        // 验证 Mapper 方法调用
        verify(ascwtmMapper, times(1)).delete(ids);
    }

    @Test
    void testSelectById() {
        Integer id = 1;
        ASCWTM mockASCWTM = new ASCWTM();
        mockASCWTM.setId(1);
        mockASCWTM.setStudentId("S123");
        mockASCWTM.setTutorName("Dr. Smith");

        when(ascwtmMapper.selectById(id)).thenReturn(mockASCWTM);

        // 调用 Service 方法
        ASCWTM result = ascwtmService.selectById(id);

        // 验证结果
        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals("S123", result.getStudentId());
        assertEquals("Dr. Smith", result.getTutorName());

        // 验证 Mapper 方法调用
        verify(ascwtmMapper, times(1)).selectById(id);
    }

    @Test
    void testSelect() {
        ASCWTM ascwtm = new ASCWTM();
        ascwtm.setTutorName("Dr. Smith");

        List<ASCWTM> mockASCWTMs = new ArrayList<>();
        ASCWTM resultASCWTM = new ASCWTM();
        resultASCWTM.setTutorName("Dr. Smith");
        mockASCWTMs.add(resultASCWTM);

        when(ascwtmMapper.select(ascwtm)).thenReturn(mockASCWTMs);

        // 调用 Service 方法
        List<ASCWTM> result = ascwtmService.select(ascwtm);

        // 验证结果
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Dr. Smith", result.get(0).getTutorName());

        // 验证 Mapper 方法调用
        verify(ascwtmMapper, times(1)).select(ascwtm);
    }

    @Test
    void testUpdate() {
        ASCWTM ascwtm = new ASCWTM();
        ascwtm.setStudentId("S123");
        ascwtm.setTutorName("Dr. Johnson");

        // 调用 Service 方法
        ascwtmService.update(ascwtm);

        // 验证 Mapper 方法调用
        verify(ascwtmMapper, times(1)).update(ascwtm);
    }
}


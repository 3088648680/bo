package test.coursedesign.service;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import test.coursedesign.mapper.GTMMapper;
import test.coursedesign.pojo.GTM;
import test.coursedesign.service.impl.GTMServiceimpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class GTMServiceimplTest {

    @InjectMocks
    private GTMServiceimpl gtmService;

    @Mock
    private GTMMapper gtmMapper;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsert() {
        GTM gtm = new GTM();
        gtm.setName("John Doe");
        gtm.setTitle("Task Coordinator");
        gtm.setContactInfo("john.doe@example.com");

        // 调用 Service 方法
        gtmService.insert(gtm);

        // 验证 Mapper 方法调用
        verify(gtmMapper, times(1)).insert(gtm);
    }

    @Test
    void testDelete() {
        List<Integer> ids = List.of(1, 2, 3);

        // 调用 Service 方法
        gtmService.delete(ids);

        // 验证 Mapper 方法调用
        verify(gtmMapper, times(1)).delete(ids);
    }



    @Test
    void testSelect2() {
        GTM query = new GTM();
        query.setName("John Doe");

        List<GTM> mockResults = new ArrayList<>();
        GTM result = new GTM();
        result.setName("John Doe");
        result.setTitle("Task Coordinator");
        mockResults.add(result);

        when(gtmMapper.select2(query)).thenReturn(mockResults);

        // 调用 Service 方法
        List<GTM> results = gtmService.select2(query);

        // 验证结果
        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals("John Doe", results.get(0).getName());
        assertEquals("Task Coordinator", results.get(0).getTitle());

        // 验证 Mapper 方法调用
        verify(gtmMapper, times(1)).select2(query);
    }

    @Test
    void testUpdate() {
        GTM gtm = new GTM();
        gtm.setName("Updated Name");
        gtm.setContactInfo("updated.email@example.com");

        // 调用 Service 方法
        gtmService.update(gtm);

        // 验证 Mapper 方法调用
        verify(gtmMapper, times(1)).update(gtm);
    }
}

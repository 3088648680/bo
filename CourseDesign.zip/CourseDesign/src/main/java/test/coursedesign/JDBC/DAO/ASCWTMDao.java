package test.coursedesign.JDBC.DAO;

import test.coursedesign.JDBC.JdbcUtils;
import test.coursedesign.pojo.ASCWTM;

import java.sql.*;
import java.util.List;

public class ASCWTMDao {

    // 批量插入 ASCWTM 数据
    public boolean batchInsertASCWTM(List<ASCWTM> ascwtmList) {
        String sql = "INSERT INTO ascwtm (student_id, tutor_name, subject_name, homework_title) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // 获取数据库连接
            conn = JdbcUtils.getConnection();
            stmt = conn.prepareStatement(sql);

            // 关闭自动提交，开启事务
            conn.setAutoCommit(false);

            // 循环添加批量插入的数据
            for (ASCWTM ascwtm : ascwtmList) {
                stmt.setString(1, ascwtm.getStudentId());
                stmt.setString(2, ascwtm.getTutorName());
                stmt.setString(3, ascwtm.getSubjectName());
                stmt.setString(4, ascwtm.getHomeworkTitle());

                // 将每一条记录添加到批处理中
                stmt.addBatch();
            }

            // 执行批量插入
            int[] result = stmt.executeBatch();

            // 提交事务
            conn.commit();

            // 如果所有插入都成功，返回 true
            return result.length == ascwtmList.size();
        } catch (SQLException e) {
            e.printStackTrace();
            // 如果出错，回滚事务
            try {
                if (conn != null) {
                    conn.rollback();  // 回滚事务
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            return false;
        } finally {
            // 关闭资源，避免内存泄漏
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("关闭资源失败：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}

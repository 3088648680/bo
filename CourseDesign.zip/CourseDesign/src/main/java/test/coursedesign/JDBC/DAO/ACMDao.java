package test.coursedesign.JDBC.DAO;

import test.coursedesign.JDBC.JdbcUtils;
import test.coursedesign.pojo.ACM;
import java.util.Date;  // 用于 java.util.Date


import java.sql.*;
import java.util.List;

public class ACMDao {

    // 批量插入 ACM 数据
    public boolean batchInsertACM(List<ACM> acmList) {
        String sql = "INSERT INTO acm (name, start_date, update_date, status) VALUES (?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // 获取数据库连接
            conn = JdbcUtils.getConnection();
            stmt = conn.prepareStatement(sql);

            // 关闭自动提交，开启事务
            conn.setAutoCommit(false);

            for (ACM acm : acmList) {
                stmt.setString(1, acm.getName());

                // 检查 startDate 是否为 null，若是，则设置为当前时间
                if (acm.getStartDate() == null) {
                    acm.setStartDate(new Date()); // 设置为当前时间
                }
                stmt.setDate(2, new java.sql.Date(acm.getStartDate().getTime()));

                if (acm.getUpdateDate() == null) {
                    acm.setUpdateDate(new Date()); // 设置为当前时间
                }
                stmt.setDate(3, new java.sql.Date(acm.getUpdateDate().getTime()));

                stmt.setString(4, acm.getStatus());

                // 将每一条记录添加到批处理中
                stmt.addBatch();
            }

            // 执行批量插入
            int[] result = stmt.executeBatch();

            // 提交事务
            conn.commit();

            // 如果所有插入都成功，返回 true
            return result.length == acmList.size();
        } catch (SQLException e) {
            // 在发生异常时打印出详细的错误信息
            System.err.println("SQL执行失败：" + e.getMessage());
            e.printStackTrace();

            try {
                // 如果出错，回滚事务
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("回滚失败：" + rollbackEx.getMessage());
                rollbackEx.printStackTrace();
            }
            return false;
        } finally {
            // 关闭资源，避免内存泄漏
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("关闭资源失败：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}


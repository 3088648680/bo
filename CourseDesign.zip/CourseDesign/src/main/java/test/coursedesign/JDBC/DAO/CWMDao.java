package test.coursedesign.JDBC.DAO;

import test.coursedesign.JDBC.JdbcUtils;
import test.coursedesign.pojo.CWM;
import java.util.Date;  // 用于 java.util.Date
import java.sql.*;
import java.util.List;

public class CWMDao {

    // 批量插入 CWM 数据
    public boolean batchInsertCWM(List<CWM> cwmList) {
        String sql = "INSERT INTO cwm (title, description,submitdate) VALUES (?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // 获取数据库连接
            conn = JdbcUtils.getConnection();
            stmt = conn.prepareStatement(sql);

            // 关闭自动提交，开启事务
            conn.setAutoCommit(false);

            for (CWM cwm : cwmList) {
                stmt.setString(1, cwm.getTitle());

                stmt.setString(2, cwm.getDescription());

                // 检查 submitDate 是否为 null，若是，则设置为当前时间
                if (cwm.getSubmitDate() == null) {
                    cwm.setSubmitDate(new Date()); // 设置为当前时间
                }
                stmt.setDate(3, new java.sql.Date(cwm.getSubmitDate().getTime()));

                // 将每一条记录添加到批处理中
                stmt.addBatch();
            }

            // 执行批量插入
            int[] result = stmt.executeBatch();

            // 提交事务
            conn.commit();

            // 如果所有插入都成功，返回 true
            return result.length == cwmList.size();
        } catch (SQLException e) {
            // 在发生异常时打印出详细的错误信息
            System.err.println("SQL执行失败：" + e.getMessage());
            e.printStackTrace();

            try {
                // 如果出错，回滚事务
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("回滚失败：" + rollbackEx.getMessage());
                rollbackEx.printStackTrace();
            }
            return false;
        } finally {
            // 关闭资源，避免内存泄漏
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("关闭资源失败：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}

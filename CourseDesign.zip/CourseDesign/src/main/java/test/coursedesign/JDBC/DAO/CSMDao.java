package test.coursedesign.JDBC.DAO;

import test.coursedesign.JDBC.JdbcUtils;
import test.coursedesign.pojo.CSM;
import java.sql.*;
import java.util.List;

public class CSMDao {

    // 批量插入 CSM 数据
    public boolean batchInsertCSM(List<CSM> csmList) {
        String sql = "INSERT INTO csm (student_id, name, major, class_name, contact_info) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // 获取数据库连接
            conn = JdbcUtils.getConnection();
            stmt = conn.prepareStatement(sql);

            // 关闭自动提交，开启事务
            conn.setAutoCommit(false);

            for (CSM csm : csmList) {
                stmt.setString(1, csm.getStudentId());
                stmt.setString(2, csm.getName());
                stmt.setString(3, csm.getMajor());
                stmt.setString(4, csm.getClassName());
                stmt.setString(5, csm.getContactInfo());

                // 将每一条记录添加到批处理中
                stmt.addBatch();
            }

            // 执行批量插入
            int[] result = stmt.executeBatch();

            // 提交事务
            conn.commit();

            // 如果所有插入都成功，返回 true
            return result.length == csmList.size();
        } catch (SQLException e) {
            // 在发生异常时打印出详细的错误信息
            System.err.println("SQL执行失败：" + e.getMessage());
            e.printStackTrace();

            try {
                // 如果出错，回滚事务
                if (conn != null) {
                    conn.rollback();
                }
            } catch (SQLException rollbackEx) {
                System.err.println("回滚失败：" + rollbackEx.getMessage());
                rollbackEx.printStackTrace();
            }
            return false;
        } finally {
            // 关闭资源，避免内存泄漏
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("关闭资源失败：" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}

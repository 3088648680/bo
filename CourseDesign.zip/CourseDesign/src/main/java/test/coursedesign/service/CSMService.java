package test.coursedesign.service;

import test.coursedesign.pojo.CSM;

import java.util.List;

public interface CSMService {
    void insert(CSM csm);
    void delete(List<Integer> ids);
//    List<CSMWithSubjects> select1(CSMWithSubjects csm);
    List<CSM> select2(CSM csm);
    void update(CSM csm);
    List<CSM> importExcel(String filePath) throws Exception;
    void exportExcel(List<CSM> dataList, String filePath) throws Exception;
}
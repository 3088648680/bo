package test.coursedesign.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import test.coursedesign.mapper.CWMMapper;
import test.coursedesign.pojo.CWM;
import test.coursedesign.service.CWMService;

import java.util.List;

@Service
public class CWMServiceimpl implements CWMService {
    @Autowired
    private CWMMapper cwmMapper;

    @Autowired
    private ExcelService excelService;


    @Override
    public void insert(CWM cwm) {
        cwmMapper.insert(cwm);
    }

    @Override
    public void delete(List<Integer> ids) {
        cwmMapper.delete(ids);
    }


    @Override
    public List<CWM> select2(CWM cwm) {
        return cwmMapper.select2(cwm);
    }

    @Override
    public void update(CWM cwm) {
        cwmMapper.update(cwm);
    }
    @Override
    public List<CWM> importExcel(String filePath) throws Exception {
        return excelService.importExcel(filePath, CWM.class);
    }

    @Override
    public void exportExcel(List<CWM> dataList, String filePath) throws Exception {
        excelService.exportExcel(dataList, filePath, CWM.class);
    }
}
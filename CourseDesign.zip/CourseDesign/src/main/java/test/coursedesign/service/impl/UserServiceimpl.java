package test.coursedesign.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import test.coursedesign.mapper.UserMapper;
import test.coursedesign.pojo.User;
import test.coursedesign.service.UserService;

import java.time.LocalDateTime;

@Service
public class UserServiceimpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public boolean registerUser(User user) {
        if (user.getUsername() == null)
            return false;
        user.setCreatTime(String.valueOf(LocalDateTime.now()));
        try {
            userMapper.registerUser(user);
            return true; // 插入成功
        } catch (Exception e) {
            return false; // 插入失败
        }
    }
    @Override
    public User login(User userLogin) {
        return userMapper.login(userLogin);
    }
    @Override
    public boolean userupdate(User user) {
        try {
            userMapper.userupdate(user);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    @Override
    public boolean userdestory(User user) {
        try {
            userMapper.userdestory(user);
            return true; // 插入成功
        } catch (Exception e) {
            return false; // 插入失败
        }
    }
}

package test.coursedesign.service;

import test.coursedesign.pojo.User;

public interface UserService {
    boolean registerUser(User user);

    User login(User userLogin);

    boolean userupdate(User user);


    boolean userdestory(User user);
}


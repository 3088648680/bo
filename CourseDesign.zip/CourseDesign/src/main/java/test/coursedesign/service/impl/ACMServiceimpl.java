package test.coursedesign.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import test.coursedesign.mapper.ACMMapper;
import test.coursedesign.pojo.ACM;
import test.coursedesign.service.ACMService;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ACMServiceimpl implements ACMService {
    @Autowired
    private ACMMapper acmMapper;

    @Autowired
    private ExcelService excelService;

    @Override
    public void insert(ACM acm)
    {
        acmMapper.insert(acm);
    }
    @Override
    public void delete(List<Integer> ids)
    {
        acmMapper.delete(ids);
    }
    @Override
    public List<ACM> select(ACM acm) {
        return acmMapper.select(acm);
    }
    @Override
    public void update(ACM acm)
    {
//        acm.setUpdate_date(LocalDateTime.now());
        acmMapper.update(acm);
    }
    @Override
    public List<ACM> importExcel(String filePath) throws Exception {
        return excelService.importExcel(filePath, ACM.class);
    }
    @Override
    public void exportExcel(List<ACM> dataList, String filePath) throws Exception {
        excelService.exportExcel(dataList, filePath, ACM.class);
    }
}

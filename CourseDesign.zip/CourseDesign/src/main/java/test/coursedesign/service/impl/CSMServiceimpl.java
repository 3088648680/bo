package test.coursedesign.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import test.coursedesign.mapper.CSMMapper;
import test.coursedesign.pojo.CSM;
import test.coursedesign.service.CSMService;

import java.util.List;

@Service
public class CSMServiceimpl implements CSMService {
    @Autowired
    private CSMMapper csmMapper;

    @Autowired
    private ExcelService excelService;

    @Override
    public void insert(CSM csm) {
        csmMapper.insert(csm);
    }

    @Override
    public void delete(List<Integer> ids) {
        csmMapper.delete(ids);
    }



    @Override
    public List<CSM> select2(CSM csm) {
        return csmMapper.select2(csm);
    }
    @Override
    public void update(CSM csm) {
        csmMapper.update(csm);
    }
    @Override
    public List<CSM> importExcel(String filePath) throws Exception {
        return excelService.importExcel(filePath, CSM.class);
    }

    @Override
    public void exportExcel(List<CSM> dataList, String filePath) throws Exception {
        excelService.exportExcel(dataList, filePath, CSM.class);
    }

}
package test.coursedesign.service;

import test.coursedesign.pojo.ASCWTM;

import java.util.List;

public interface ASCWTMService {
    void insert(ASCWTM ascwtm);
    void delete(List<Integer> ids);
    ASCWTM selectById(Integer id);
    List<ASCWTM> select(ASCWTM ascwtm);
    void update(ASCWTM ascwtm);
    List<ASCWTM> importExcel(String filePath) throws Exception;
    void exportExcel(List<ASCWTM> dataList, String filePath) throws Exception;
}

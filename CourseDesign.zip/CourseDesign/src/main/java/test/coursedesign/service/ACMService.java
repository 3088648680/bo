package test.coursedesign.service;

import test.coursedesign.pojo.ACM;

import java.util.List;

public interface ACMService {

    void insert(ACM acm);

    void delete(List<Integer> ids);

    List<ACM> select(ACM acm);

    void update(ACM acm);

    List<ACM> importExcel(String filePath) throws Exception;

    void exportExcel(List<ACM> dataList, String filePath) throws Exception;

}

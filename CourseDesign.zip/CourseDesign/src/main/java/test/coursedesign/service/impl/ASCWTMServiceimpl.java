package test.coursedesign.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import test.coursedesign.mapper.ASCWTMMapper;
import test.coursedesign.pojo.ASCWTM;
import test.coursedesign.service.ASCWTMService;

import java.util.List;

@Service
public class ASCWTMServiceimpl implements ASCWTMService {
    @Autowired
    private ASCWTMMapper ascwtmMapper;

    @Autowired
    private ExcelService excelService;

    @Override
    public void insert(ASCWTM ascwtm) {
        ascwtmMapper.insert(ascwtm);
    }

    @Override
    public void delete(List<Integer> ids) {
        ascwtmMapper.delete(ids);
    }

    @Override
    public ASCWTM selectById(Integer id) {
        return ascwtmMapper.selectById(id);
    }

    @Override
    public List<ASCWTM> select(ASCWTM ascwtm) {
        return ascwtmMapper.select(ascwtm);
    }

    @Override
    public void update(ASCWTM ascwtm) {
        ascwtmMapper.update(ascwtm);
    }

    @Override
    public List<ASCWTM> importExcel(String filePath) throws Exception {
        return excelService.importExcel(filePath, ASCWTM.class);
    }

    @Override
    public void exportExcel(List<ASCWTM> dataList, String filePath) throws Exception {
        excelService.exportExcel(dataList, filePath, ASCWTM.class);
    }
}

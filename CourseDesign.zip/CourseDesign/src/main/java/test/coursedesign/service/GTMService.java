package test.coursedesign.service;

import test.coursedesign.pojo.GTM;

import java.util.List;

public interface GTMService {
    void insert(GTM gtm);
    void delete(List<Integer> ids);
//    List<GTMWithDetails> select1(GTMWithDetails gtm);
    List<GTM> select2(GTM gtm);
    void update(GTM gtm);
    List<GTM> importExcel(String filePath) throws Exception;
    void exportExcel(List<GTM> dataList, String filePath) throws Exception;
}
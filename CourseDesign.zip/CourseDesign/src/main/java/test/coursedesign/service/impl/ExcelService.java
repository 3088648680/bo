package test.coursedesign.service.impl;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Service
public class ExcelService {

    public <T> List<T> importExcel(String filePath, Class<T> clazz) throws Exception {
        List<T> list = new ArrayList<>();
        try (InputStream inputStream = new FileInputStream(filePath)) {
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet sheet = workbook.getSheetAt(0);
            Field[] fields = clazz.getDeclaredFields();
            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // 跳过标题行
                T obj = clazz.newInstance();
                for (Cell cell : row) {
                    Field field = fields[cell.getColumnIndex()];
                    field.setAccessible(true);
                    Object value = convertCellValue(cell);
                    field.set(obj, value);
                }
                list.add(obj);
            }
        }
        return list;
    }

    public <T> void exportExcel(List<T> dataList, String filePath, Class<T> clazz) throws Exception {
        try (OutputStream outputStream = new FileOutputStream(filePath)) {
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet();
            Row headerRow = sheet.createRow(0);
            Field[] fields = clazz.getDeclaredFields();
            for (int i = 0; i < fields.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(fields[i].getName());
            }
            for (int i = 0; i < dataList.size(); i++) {
                Row row = sheet.createRow(i + 1);
                T obj = dataList.get(i);
                for (int j = 0; j < fields.length; j++) {
                    Cell cell = row.createCell(j);
                    fields[j].setAccessible(true);
                    Object value = fields[j].get(obj);
                    cell.setCellValue(value.toString());
                }
            }
            workbook.write(outputStream);
        }
    }

    private Object convertCellValue(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue();
                } else {
                    return cell.getNumericCellValue();
                }
            case BOOLEAN:
                return cell.getBooleanCellValue();
            case FORMULA:
                return cell.getCellFormula();
            default:
                return null;
        }
    }
}
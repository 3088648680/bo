package test.coursedesign.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import test.coursedesign.mapper.GTMMapper;
import test.coursedesign.pojo.GTM;
import test.coursedesign.service.GTMService;

import java.util.List;

@Service
public class GTMServiceimpl implements GTMService {
    @Autowired
    private GTMMapper gtmMapper;

    @Autowired
    private ExcelService excelService;

    @Override
    public void insert(GTM gtm) {
        gtmMapper.insert(gtm);
    }

    @Override
    public void delete(List<Integer> ids) {
        gtmMapper.delete(ids);
    }

    @Override
    public List<GTM> select2(GTM gtm) {
        return gtmMapper.select2(gtm);
    }


    @Override
    public void update(GTM gtm) {
        gtmMapper.update(gtm);
    }
    @Override
    public List<GTM> importExcel(String filePath) throws Exception {
        return excelService.importExcel(filePath, GTM.class);
    }

    @Override
    public void exportExcel(List<GTM> dataList, String filePath) throws Exception {
        excelService.exportExcel(dataList, filePath, GTM.class);
    }

}
package test.coursedesign.service;

import test.coursedesign.pojo.CWM;

import java.util.List;

public interface CWMService {
    void insert(CWM cwm);
    void delete(List<Integer> ids);
//    List<CWMWithDetails> select1(CWMWithDetails cwm);
    List<CWM> select2(CWM cwm);
    void update(CWM cwm);
    List<CWM> importExcel(String filePath) throws Exception;
    void exportExcel(List<CWM> dataList, String filePath) throws Exception;
}
package test.coursedesign.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CSM {
    private Integer id;
    private String studentId;
    private String name;
    private String major;
    private String className;
    private String contactInfo;
}
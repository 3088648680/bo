package test.coursedesign.util;

import io.jsonwebtoken.*;
import test.coursedesign.pojo.User;

import java.util.Date;

public class JwtUtil {
    private static final String SECRET_KEY = "your_secret_key"; // 替换为自己的密钥

    /**
     * 生成JWT
     */
    public static String generateToken(User user) {
        return Jwts.builder()
                .setSubject(user.getUsername()) // 设置主题为用户名
                .claim("role", user.getRole()) // 可添加更多信息
                .setIssuedAt(new Date()) // 签发时间
                .setExpiration(new Date(System.currentTimeMillis() + 3600000)) // 1小时有效期
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY) // 使用HS256算法签名
                .compact();
    }

    /**
     * 验证JWT
     */
    public static Claims parseToken(String token) throws ExpiredJwtException, MalformedJwtException {
        Claims claims = Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody();

        // 手动将 exp 转换为 Date 类型
        if (claims.containsKey("exp")) {
            int exp = (int) claims.get("exp"); // 获取Unix时间戳
            claims.put("exp", new Date(exp * 1000L)); // 将 Unix 时间戳转换为 Date 对象
        }

        return claims;
    }
}
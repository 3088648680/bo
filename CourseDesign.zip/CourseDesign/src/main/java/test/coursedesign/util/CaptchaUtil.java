package test.coursedesign.util;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class CaptchaUtil {

    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int CAPTCHA_LENGTH = 4;
    private static final int WIDTH = 120;
    private static final int HEIGHT = 50;

    /**
     * 生成随机验证码文本
     */
    public static String generateCaptchaText() {
        StringBuilder captcha = new StringBuilder();
        ThreadLocalRandom random = ThreadLocalRandom.current();  // 使用线程安全的随机数生成器
        for (int i = 0; i < CAPTCHA_LENGTH; i++) {
            captcha.append(CHARACTERS.charAt(random.nextInt(CHARACTERS.length())));
        }
        return captcha.toString();
    }

    /**
     * 生成验证码图片，返回Base64编码的图片数据
     */
    public static String generateCaptchaImage(String captcha) throws IOException {
        // 创建图像
        BufferedImage image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();

        // 设置背景颜色
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        // 设置字体
        Font font = new Font("Arial", Font.BOLD, 40);
        g.setFont(font);

        // 绘制干扰线
        drawDisturbingLines(g);

        // 绘制验证码文本
        drawCaptchaText(g, captcha);

        g.dispose();

        // 将图片转换为Base64
        return encodeImageToBase64(image);
    }

    /**
     * 绘制干扰线
     */
    private static void drawDisturbingLines(Graphics2D g) {
        Random random = ThreadLocalRandom.current();  // 使用线程安全的随机数生成器
        g.setColor(Color.LIGHT_GRAY);
        for (int i = 0; i < 3; i++) {
            int x = random.nextInt(WIDTH);
            int y = random.nextInt(HEIGHT);
            int xl = random.nextInt(12);
            int yl = random.nextInt(12);
            g.drawLine(x, y, x + xl, y + yl);
        }
    }

    /**
     * 绘制验证码文本
     */
    private static void drawCaptchaText(Graphics2D g, String captcha) {
        g.setColor(Color.BLUE);
        for (int i = 0; i < captcha.length(); i++) {
            char c = captcha.charAt(i);
            g.drawString(String.valueOf(c), 20 * i + 10, 35);
        }
    }

    /**
     * 将验证码图像转换为Base64编码的字符串
     */
    private static String encodeImageToBase64(BufferedImage image) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos);
        byte[] bytes = baos.toByteArray();
        return Base64.getEncoder().encodeToString(bytes);
    }
}

package test.coursedesign.mapper;
import org.apache.ibatis.annotations.*;
import test.coursedesign.pojo.ACM;

import java.util.List;
@Mapper
public interface ACMMapper {

    @Insert("insert into acm(name,start_date,update_date,status)"+ "values(#{name},#{startDate},#{updateDate},#{status})")
    void insert(ACM acm);

    void delete(List<Integer> ids);

    List<ACM> select(ACM acm);

    void update(ACM acm);

}

package test.coursedesign.mapper;

import org.apache.ibatis.annotations.*;
import test.coursedesign.pojo.GTM;

import java.util.List;

@Mapper
public interface GTMMapper {
    @Insert("INSERT INTO GTM(name, title, contact_info) " +
            "VALUES(#{name}, #{title}, #{contactInfo})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(GTM gtm);

    void delete(List<Integer> ids);

    List<GTM> select2(GTM gtm);

    void update(GTM gtm);
}
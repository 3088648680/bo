package test.coursedesign.mapper;

import org.apache.ibatis.annotations.*;
import test.coursedesign.pojo.User;
@Mapper
public interface UserMapper {

    void registerUser(User user);

    @Select("select * from user where username = #{username} and password = #{password}")
    User login(User userLogin);

    void userupdate(User user);

    @Delete("delete from user where username=#{username}")
    void userdestory(User user);
}

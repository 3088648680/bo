package test.coursedesign.mapper;

import org.apache.ibatis.annotations.*;
import test.coursedesign.pojo.CSM;

import java.util.List;

@Mapper
public interface CSMMapper {

    @Insert("INSERT INTO CSM(student_id, name, major, class_name, contact_info) " +
            "VALUES(#{studentId}, #{name}, #{major}, #{className}, #{contactInfo})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(CSM csm);

    void delete(List<Integer> ids);

    List<CSM> select2(CSM csm);

    void update(CSM csm);

}
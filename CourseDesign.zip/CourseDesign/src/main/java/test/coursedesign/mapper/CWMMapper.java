package test.coursedesign.mapper;

import org.apache.ibatis.annotations.*;
import test.coursedesign.pojo.CWM;

import java.util.List;

@Mapper
public interface CWMMapper {
    @Insert("INSERT INTO CWM(title, description, submitdate) " +
            "VALUES(#{title}, #{description}, #{submitDate})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(CWM cwm);

    void delete(List<Integer> ids);

    List<CWM> select2(CWM cwm);

    void update(CWM cwm);
}
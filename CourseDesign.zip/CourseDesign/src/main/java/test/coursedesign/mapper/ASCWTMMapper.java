package test.coursedesign.mapper;

import org.apache.ibatis.annotations.Mapper;
import test.coursedesign.pojo.ASCWTM;

import java.util.List;

@Mapper
public interface ASCWTMMapper {
    void insert(ASCWTM ascwtm);

    void delete(List<Integer> ids);

    ASCWTM selectById(Integer id);

    List<ASCWTM> select(ASCWTM ascwtm);

    void update(ASCWTM ascwtm);
}

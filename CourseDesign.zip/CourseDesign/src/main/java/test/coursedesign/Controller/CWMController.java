package test.coursedesign.Controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import test.coursedesign.JDBC.DAO.CWMDao;
import test.coursedesign.pojo.*;
import test.coursedesign.service.CWMService;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
public class CWMController {
    @Autowired
    private CWMService cwmService;

    @PostMapping("/api/homework/add")
    public Result insert(@RequestBody CWM cwm) {
        log.info("作业信息添加");
        cwmService.insert(cwm);
        return Result.success();
    }

    @PostMapping("/api/homework/delete")
    public Result delete(@RequestBody List<Integer> ids) {
        log.info("作业信息删除");
        cwmService.delete(ids);
        return Result.success();
    }

    @PostMapping("/api/homework/info2")
    public Result info(@RequestBody CWM cwm) {
        log.info("获取作业信息");
        return Result.success(cwmService.select2(cwm));
    }

    @PostMapping("/api/homework/update")
    public Result update(@RequestBody CWM cwm) {
        log.info("作业信息更新");
        cwmService.update(cwm);
        return Result.success();
    }
    private final CWMDao cwmDao = new CWMDao();
    @PostMapping("/api/homework/import")
    public Result importExcel(@RequestParam("file") MultipartFile file) {
        List<CWM> cwmList = new ArrayList<>();
        try (InputStream fis = file.getInputStream()) {
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // 跳过表头

                CWM cwm = new CWM();

                // 解析 Title
                Cell titleCell = row.getCell(0);
                cwm.setTitle(getCellValue(titleCell));

                // 解析 Description
                Cell descriptionCell = row.getCell(1);
                cwm.setDescription(getCellValue(descriptionCell));

                // 解析 Submit Date
                Cell submitDateCell = row.getCell(2);
                cwm.setSubmitDate(parseDateCell(submitDateCell));

                cwmList.add(cwm);
            }

            // 批量插入数据到数据库
            boolean success = cwmDao.batchInsertCWM(cwmList);
            if (success) {
                return Result.success("导入成功");
            } else {
                return Result.error("导入失败");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error("文件解析失败");
        }
    }

    // 获取单元格的值
    private String getCellValue(Cell cell) {
        if (cell == null) return null;

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return new SimpleDateFormat("yyyy-MM-dd").format(cell.getDateCellValue());
                } else {
                    return String.valueOf(cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return null;
        }
    }

    // 解析日期单元格
    private Date parseDateCell(Cell cell) {
        if (cell == null) return null;

        try {
            if (cell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(cell)) {
                return cell.getDateCellValue(); // 正常解析日期
            } else if (cell.getCellType() == CellType.STRING) {
                String dateStr = cell.getStringCellValue();
                if (dateStr != null && !dateStr.isEmpty()) {
                    List<String> patterns = Arrays.asList("yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "EEE MMM dd HH:mm:ss z yyyy");
                    for (String pattern : patterns) {
                        try {
                            return new SimpleDateFormat(pattern).parse(dateStr); // 尝试解析多种日期格式
                        } catch (ParseException e) {
                            // 跳过无法解析的日期格式
                        }
                    }
                    System.err.println("无法解析日期: " + dateStr);
                }
            }
        } catch (Exception e) {
            System.err.println("日期解析失败：" + e.getMessage());
        }
        return null;
    }

    @PostMapping("/api/homework/export")
    public ResponseEntity<Resource> exportExcel(@RequestBody CWM cwm) {
        try {
            List<CWM> cwmList = cwmService.select2(cwm);
            String fileName = "exported_file_" + System.currentTimeMillis() + ".xlsx";
            String tempDir = System.getProperty("java.io.tmpdir"); // 使用临时目录
            String filePath = tempDir + File.separator + fileName;
            cwmService.exportExcel(cwmList, filePath);

            // 创建Resource对象
            Resource resource = new UrlResource(Paths.get(filePath).toUri());
            if (resource.exists() || resource.isReadable()) {
                // 设置HTTP响应头
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

                // 使用ResponseEntity包装Resource
                return ResponseEntity.ok()
                        .headers(headers)
                        .body(resource);
            } else {
                // 如果文件不存在或不可读，返回错误信息
                String errorMessage = "文件不可读或不存在";
                Resource errorResource = new ByteArrayResource(errorMessage.getBytes(StandardCharsets.UTF_8));
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=error_message.txt");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).headers(headers).body(errorResource);
            }
        } catch (Exception e) {
            log.error("导出失败", e);
            // 创建一个包含错误信息的字节数组
            byte[] errorBytes = ("导出失败: " + e.getMessage()).getBytes(StandardCharsets.UTF_8);
            // 创建一个ByteArrayResource对象，用于包装字节数组
            Resource errorResource = new ByteArrayResource(errorBytes);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export_error.txt");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(errorResource);
        }
    }
}
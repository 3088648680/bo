package test.coursedesign.Controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import test.coursedesign.JDBC.DAO.ASCWTMDao;
import test.coursedesign.pojo.ASCWTM;
import test.coursedesign.pojo.Result;
import test.coursedesign.service.ASCWTMService;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/ascwtm")
public class ASCWTMController {
    @Autowired
    private ASCWTMService ascwtmService;

    @PostMapping("/add")
    public Result insert(@RequestBody ASCWTM ascwtm) {
        log.info("新增ASCWTM数据");
        ascwtmService.insert(ascwtm);
        return Result.success();
    }

    @PostMapping("/delete")
    public Result delete(@RequestBody List<Integer> ids) {
        log.info("删除ASCWTM数据");
        ascwtmService.delete(ids);
        return Result.success();
    }

    @PostMapping("/info")
    public Result select(@RequestBody ASCWTM ascwtm) {
        log.info("查询ASCWTM数据");
        return Result.success(ascwtmService.select(ascwtm));
    }

    @PostMapping("/update")
    public Result update(@RequestBody ASCWTM ascwtm) {
        log.info("更新ASCWTM数据");
        ascwtmService.update(ascwtm);
        return Result.success();
    }

    private final ASCWTMDao ascwtmDao = new ASCWTMDao();
    @PostMapping("/import")
    public Result importExcel(@RequestParam("file") MultipartFile file) {
        List<ASCWTM> ascwtmList = new ArrayList<>();
        try (InputStream fis = file.getInputStream()) {
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // 跳过表头

                ASCWTM ascwtm = new ASCWTM();

                // 解析 Student ID
                Cell studentIdCell = row.getCell(0);
                ascwtm.setStudentId(getCellValue(studentIdCell));

                // 解析 Tutor Name
                Cell tutorNameCell = row.getCell(1);
                ascwtm.setTutorName(getCellValue(tutorNameCell));

                // 解析 Subject Name
                Cell subjectNameCell = row.getCell(2);
                ascwtm.setSubjectName(getCellValue(subjectNameCell));

                // 解析 Homework Title
                Cell homeworkTitleCell = row.getCell(3);
                ascwtm.setHomeworkTitle(getCellValue(homeworkTitleCell));

                ascwtmList.add(ascwtm);
            }

            // 批量插入数据到数据库
            boolean success = ascwtmDao.batchInsertASCWTM(ascwtmList);
            if (success) {
                return Result.success("导入成功");
            } else {
                return Result.error("导入失败");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error("文件解析失败");
        }
    }

    // 获取单元格的值
    private String getCellValue(Cell cell) {
        if (cell == null) return null;

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return null;
        }
    }


    @PostMapping("/export")
    public ResponseEntity<Resource> exportExcel(@RequestBody ASCWTM ascwtm) {
        try {
            List<ASCWTM> cwmList = ascwtmService.select(ascwtm);
            String fileName = "exported_file_" + System.currentTimeMillis() + ".xlsx";
            String tempDir = System.getProperty("java.io.tmpdir"); // 使用临时目录
            String filePath = tempDir + File.separator + fileName;
            ascwtmService.exportExcel(cwmList, filePath);

            // 创建Resource对象
            Resource resource = new UrlResource(Paths.get(filePath).toUri());
            if (resource.exists() || resource.isReadable()) {
                // 设置HTTP响应头
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

                // 使用ResponseEntity包装Resource
                return ResponseEntity.ok()
                        .headers(headers)
                        .body(resource);
            } else {
                // 如果文件不存在或不可读，返回错误信息
                String errorMessage = "文件不可读或不存在";
                Resource errorResource = new ByteArrayResource(errorMessage.getBytes(StandardCharsets.UTF_8));
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=error_message.txt");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).headers(headers).body(errorResource);
            }
        } catch (Exception e) {
            log.error("导出失败", e);
            // 创建一个包含错误信息的字节数组
            byte[] errorBytes = ("导出失败: " + e.getMessage()).getBytes(StandardCharsets.UTF_8);
            // 创建一个ByteArrayResource对象，用于包装字节数组
            Resource errorResource = new ByteArrayResource(errorBytes);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export_error.txt");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(errorResource);
        }
    }
}

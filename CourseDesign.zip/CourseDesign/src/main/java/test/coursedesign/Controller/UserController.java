package test.coursedesign.Controller;

import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import test.coursedesign.pojo.Result;
import test.coursedesign.pojo.User;
import test.coursedesign.service.UserService;
import test.coursedesign.util.CaptchaUtil;
import test.coursedesign.util.JwtUtil;

import java.io.IOException;
import java.util.Map;

@Slf4j
@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/user/register")
    public Result register(@RequestBody User user) {
        if (userService.registerUser(user)) {
            log.info("注册成功");
            // 注册成功后生成并返回token
            String token = JwtUtil.generateToken(user); // 生成JWT
            return Result.success( token);
        } else {
            log.info("注册失败");
            return Result.error("注册失败");
        }
    }
    @PostMapping("/user/login")
    public Result login(@RequestBody Map<String, String> loginData, HttpSession session) {
        String username = loginData.get("username");
        String password = loginData.get("password");
        String captcha = loginData.get("captcha");

        // 验证验证码
        String correctCaptcha = (String) session.getAttribute("captcha");
        if (correctCaptcha == null || !correctCaptcha.equalsIgnoreCase(captcha)) {
            return Result.error("验证码错误，请重试");
        }
        session.removeAttribute("captcha");

        // 验证用户名和密码
        User userLogin = new User();
        userLogin.setUsername(username);
        userLogin.setPassword(password);
        User e = userService.login(userLogin);

        if (e == null) {
            return Result.error("账号或者密码错误");
        }

        // 登录成功后生成并返回token
        String token = JwtUtil.generateToken(e);
//        System.out.println(Result.success(token));
        return Result.success(token);
    }



//    @PostMapping("/user/account")
//    public Result accountManage(@RequestBody User user) {
//        if (userService.userupdate(user)) {
//            return Result.success();
//        } else {
//            return Result.error("修改信息失败");
//        }
//    }
//
//    @PostMapping("/user/destory")
//    public Result destory(@RequestBody User user) {
//        if (userService.userdestory(user)) {
//            return Result.success();
//        } else {
//            return Result.error("注销成功");
//        }
//    }

    @PostMapping("/user/generate-captcha")
    public Result generateCaptcha(HttpSession session) throws IOException {
        String captchaText = CaptchaUtil.generateCaptchaText();
        session.setAttribute("captcha", captchaText); // 将验证码存入session
        String captchaBase64 = CaptchaUtil.generateCaptchaImage(captchaText);
        return Result.success(captchaBase64);
    }


}

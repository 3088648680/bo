package test.coursedesign.Controller;


import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import test.coursedesign.JDBC.DAO.ACMDao;
import test.coursedesign.pojo.ACM;
import test.coursedesign.pojo.Result;
import test.coursedesign.service.ACMService;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
public class ACMController {
    @Autowired
    private ACMService acmService;
    @PostMapping("/api/competition/add")
    public Result insert(@RequestBody ACM acm)
    {
        log.info("竞赛信息添加");
        acmService.insert(acm);
        return Result.success();
    }
    @PostMapping("/api/competition/delete")
    public Result delete(@RequestBody List<Integer> ids)
    {
        log.info("竞赛信息删除");
        System.out.println("Received IDs: " + ids);
        acmService.delete(ids);
        return Result.success();
    }
    @PostMapping("/api/competition/info")
    public Result info(@RequestBody ACM acm) {
        log.info("获取竞赛信息");
        return Result.success(acmService.select(acm));
    }
    @PostMapping("/api/competition/update")
    public Result update(@RequestBody ACM acm)
    {
        log.info("竞赛信息更新");
        acmService.update(acm);
        return Result.success();
    }
    private final ACMDao acmDao = new ACMDao();
    @PostMapping("/api/competition/import")
    public Result importExcel(@RequestParam("file") MultipartFile file) {
        List<ACM> acmList = new ArrayList<>();

        try (InputStream fis = file.getInputStream()) { // 使用 MultipartFile 的输入流
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // 跳过表头

                ACM acm = new ACM();

                // 解析 Name
                Cell nameCell = row.getCell(0); // 假设 Name 在第 1 列
                acm.setName(getCellValue(nameCell));

                // 解析 Start Date
                Cell startDateCell = row.getCell(1); // 假设 Start Date 在第 2 列
                acm.setStartDate(parseDateCell(startDateCell));

                // 解析 Update Date
                Cell updateDateCell = row.getCell(2); // 假设 Update Date 在第 3 列
                acm.setUpdateDate(parseDateCell(updateDateCell));

                // 解析 Status
                Cell statusCell = row.getCell(3); // 假设 Status 在第 4 列
                acm.setStatus(getCellValue(statusCell));

                acmList.add(acm);
            }

            // 批量插入数据到数据库
            boolean success = acmDao.batchInsertACM(acmList);
            if (success) {
                return Result.success("导入成功");
            } else {
                return Result.error("导入失败");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error("文件解析失败");
        }
    }

    // 获取单元格的值
    private String getCellValue(Cell cell) {
        if (cell == null) return null;

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return new SimpleDateFormat("yyyy-MM-dd").format(cell.getDateCellValue());
                } else {
                    return String.valueOf(cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return null;
        }
    }

    // 解析日期单元格
    private Date parseDateCell(Cell cell) {
        if (cell == null) return null;

        try {
            if (cell.getCellType() == CellType.NUMERIC && DateUtil.isCellDateFormatted(cell)) {
                return cell.getDateCellValue();
            } else if (cell.getCellType() == CellType.STRING) {
                String dateStr = cell.getStringCellValue();
                if (dateStr != null && !dateStr.isEmpty()) {
                    List<String> patterns = Arrays.asList("yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "EEE MMM dd HH:mm:ss z yyyy");
                    for (String pattern : patterns) {
                        try {
                            return new SimpleDateFormat(pattern).parse(dateStr);
                        } catch (ParseException e) {
                            // 跳过无法解析的日期格式
                        }
                    }
                    throw new IllegalArgumentException("无法解析日期: " + dateStr);
                }
            }
        } catch (Exception e) {
            System.err.println("日期解析失败：" + e.getMessage());
        }
        return null; // 无法解析时返回 null
    }



    @PostMapping("/api/competition/export")
    public ResponseEntity<Resource> exportExcel(@RequestBody ACM acm) {
        try {
            List<ACM> acmList = acmService.select(acm);
            String fileName = "exported_file_" + System.currentTimeMillis() + ".xlsx";
            String tempDir = System.getProperty("java.io.tmpdir"); // 使用临时目录
            String filePath = tempDir + File.separator + fileName;
            acmService.exportExcel(acmList, filePath);

            // 创建Resource对象
            Resource resource = new UrlResource(Paths.get(filePath).toUri());
            if (resource.exists() || resource.isReadable()) {
                // 设置HTTP响应头
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

                // 使用ResponseEntity包装Resource
                return ResponseEntity.ok()
                        .headers(headers)
                        .body(resource);
            } else {
                // 如果文件不存在或不可读，返回错误信息
                String errorMessage = "文件不可读或不存在";
                Resource errorResource = new ByteArrayResource(errorMessage.getBytes(StandardCharsets.UTF_8));
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=error_message.txt");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).headers(headers).body(errorResource);
            }
        } catch (Exception e) {
            log.error("导出失败", e);
            // 创建一个包含错误信息的字节数组
            byte[] errorBytes = ("导出失败: " + e.getMessage()).getBytes(StandardCharsets.UTF_8);
            // 创建一个ByteArrayResource对象，用于包装字节数组
            Resource errorResource = new ByteArrayResource(errorBytes);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export_error.txt");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(errorResource);
        }
    }
}



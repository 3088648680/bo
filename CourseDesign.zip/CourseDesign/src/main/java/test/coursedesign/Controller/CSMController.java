package test.coursedesign.Controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import test.coursedesign.JDBC.DAO.CSMDao;
import test.coursedesign.pojo.CSM;
import test.coursedesign.pojo.Result;
import test.coursedesign.service.CSMService;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
public class CSMController {
    @Autowired
    private CSMService csmService;

    @PostMapping("/api/student/add")
    public Result insert(@RequestBody CSM csm) {
        log.info("学生信息添加");
        csmService.insert(csm);
        return Result.success();
    }

    @PostMapping("/api/student/delete")
    public Result delete(@RequestBody List<Integer> ids) {
        log.info("学生信息删除");
        csmService.delete(ids);
        return Result.success();
    }

    @PostMapping("/api/student/info2")
    public Result info2(@RequestBody CSM csm) {
        log.info("获取学生信息");
        return Result.success(csmService.select2(csm));
    }
    @PostMapping("/api/student/update")
    public Result update(@RequestBody CSM csm) {
        log.info("学生信息更新");
        csmService.update(csm);
        return Result.success();
    }
    private final CSMDao csmDao = new CSMDao();
    @PostMapping("/api/student/import")
    public Result importExcel(@RequestParam("file") MultipartFile file) {
        List<CSM> csmList = new ArrayList<>();

        try (InputStream fis = file.getInputStream()) { // 使用 MultipartFile 的输入流
            Workbook workbook = new XSSFWorkbook(fis);
            Sheet sheet = workbook.getSheetAt(0); // 获取第一个工作表

            for (Row row : sheet) {
                if (row.getRowNum() == 0) continue; // 跳过表头

                CSM csm = new CSM();

                // 解析 studentId
                Cell studentIdCell = row.getCell(0); // 假设 studentId 在第 1 列
                csm.setStudentId(getCellValue(studentIdCell));

                // 解析 name
                Cell nameCell = row.getCell(1); // 假设 name 在第 2 列
                csm.setName(getCellValue(nameCell));

                // 解析 major
                Cell majorCell = row.getCell(2); // 假设 major 在第 3 列
                csm.setMajor(getCellValue(majorCell));

                // 解析 className
                Cell classNameCell = row.getCell(3); // 假设 className 在第 4 列
                csm.setClassName(getCellValue(classNameCell));

                // 解析 contactInfo
                Cell contactInfoCell = row.getCell(4); // 假设 contactInfo 在第 5 列
                csm.setContactInfo(getCellValue(contactInfoCell));

                csmList.add(csm);
            }

            // 批量插入数据到数据库
            boolean success = csmDao.batchInsertCSM(csmList);
            if (success) {
                return Result.success("导入成功");
            } else {
                return Result.error("导入失败");
            }
        } catch (IOException e) {
            e.printStackTrace();
            return Result.error("文件解析失败");
        }
    }

    // 获取单元格的值
    private String getCellValue(Cell cell) {
        if (cell == null) return null;

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                return String.valueOf(cell.getNumericCellValue());
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            default:
                return null;
        }
    }

    @PostMapping("/api/student/export")
    public ResponseEntity<Resource> exportExcel(@RequestBody CSM csm) {
        try {
            List<CSM> csmList = csmService.select2(csm);
            String fileName = "exported_file_" + System.currentTimeMillis() + ".xlsx";
            String tempDir = System.getProperty("java.io.tmpdir"); // 使用临时目录
            String filePath = tempDir + File.separator + fileName;
            csmService.exportExcel(csmList, filePath);

            // 创建Resource对象
            Resource resource = new UrlResource(Paths.get(filePath).toUri());
            if (resource.exists() || resource.isReadable()) {
                // 设置HTTP响应头
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_OCTET_STREAM_VALUE);

                // 使用ResponseEntity包装Resource
                return ResponseEntity.ok()
                        .headers(headers)
                        .body(resource);
            } else {
                // 如果文件不存在或不可读，返回错误信息
                String errorMessage = "文件不可读或不存在";
                Resource errorResource = new ByteArrayResource(errorMessage.getBytes(StandardCharsets.UTF_8));
                HttpHeaders headers = new HttpHeaders();
                headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
                headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=error_message.txt");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).headers(headers).body(errorResource);
            }
        } catch (Exception e) {
            log.error("导出失败", e);
            // 创建一个包含错误信息的字节数组
            byte[] errorBytes = ("导出失败: " + e.getMessage()).getBytes(StandardCharsets.UTF_8);
            // 创建一个ByteArrayResource对象，用于包装字节数组
            Resource errorResource = new ByteArrayResource(errorBytes);
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=export_error.txt");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(errorResource);
        }
    }
}

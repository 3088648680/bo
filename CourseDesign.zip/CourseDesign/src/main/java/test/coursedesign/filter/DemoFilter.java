package test.coursedesign.filter;

import com.alibaba.fastjson2.JSONObject;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;
import test.coursedesign.pojo.Result;
import test.coursedesign.util.JwtUtil;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

@Slf4j
@WebFilter(urlPatterns = "/*")
public class DemoFilter implements Filter {
        @Override
        public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
                throws IOException, ServletException {
            HttpServletRequest req = (HttpServletRequest) servletRequest;
            HttpServletResponse resp = (HttpServletResponse) servletResponse;

            String url = req.getRequestURI();
            log.info("请求的URL: {}", url);

            // 白名单请求，直接放行
            if (isWhitelisted(url)) {
                log.info("白名单请求，放行...");
                filterChain.doFilter(servletRequest, servletResponse);
                return;
            }

            // 从请求头中获取 Authorization 信息
            String authorizationHeader = req.getHeader("Authorization");

            // 检查请求头中是否有 token
            if (StringUtils.isEmpty(authorizationHeader) || !authorizationHeader.startsWith("Bearer ")) {
                log.info("请求头中的token为空，返回未登录信息");
                sendErrorResponse(resp, Result.error("NOT LOGIN"));
                return;
            }

            // 从 Authorization 头中提取 token
            String jwt = authorizationHeader.substring(7); // 去除 Bearer 前缀

            // 验证Token
            boolean isValid = validateToken(jwt);
            if (!isValid) {
                log.info("无效的token，返回未授权信息");
                sendErrorResponse(resp, Result.error("UNAUTHORIZED"));
                return;
            }

            // Token有效，继续执行过滤器链
            filterChain.doFilter(servletRequest, servletResponse);
        }

        // 白名单规则
        public boolean isWhitelisted(String url) {
            // 放行首页和静态资源
            return url.equals("/") ||
                    url.endsWith(".html") ||
                    url.endsWith(".css") ||
                    url.endsWith(".js") ||
                    url.endsWith(".png") ||
                    url.endsWith(".jpg") ||
                    url.endsWith(".jpeg") ||
                    url.contains("/user/login") ||
                    url.contains("/user/register") ||
                    url.contains("/user/generate-captcha") ||
                    url.equals("/favicon.ico"); // 忽略 favicon.ico 请求
        }

        // Token验证逻辑
        public boolean validateToken(String jwt) {
            try {
                // 使用 JwtUtil 来解析和验证 token
                Map<String, Object> claims = JwtUtil.parseToken(jwt); // 解析 token

                // 你可以在这里添加更多验证逻辑，例如检查 token 中的角色、权限等
                // 如果需要，还可以检查过期时间或其他 claims
                if (claims != null) {
                    // 判断 token 是否过期（如果有过期字段）
                    Date expiration = (Date) claims.get("exp");
                    return expiration != null && expiration.after(new Date()); // 确保 token 还未过期
                }
                return false;
            } catch (Exception e) {
                log.error("Token解析失败: ", e);
                return false; // token 无效
            }
        }

        // 错误响应处理
        private void sendErrorResponse(HttpServletResponse resp, Result errorResult) throws IOException {
            String errorResponse = JSONObject.toJSONString(errorResult);
            resp.setContentType("application/json;charset=utf-8");
            resp.getWriter().write(errorResponse);
        }
    }
